package com.example.telusko_quizz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeluskoQuizzApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeluskoQuizzApplication.class, args);
	}

}
