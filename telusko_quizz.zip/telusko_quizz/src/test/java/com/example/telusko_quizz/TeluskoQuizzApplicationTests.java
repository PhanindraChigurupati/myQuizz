package com.example.telusko_quizz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeluskoQuizzApplicationTests {

	@Test
	void contextLoads() {
	}

}
